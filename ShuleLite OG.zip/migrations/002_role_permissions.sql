CREATE TABLE IF NOT EXISTS permission_catalog (
 permission_key VARCHAR(80) PRIMARY KEY,
 label_key VARCHAR(100) NOT NULL,
 scope ENUM('platform','school') NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO permission_catalog(permission_key,label_key,scope,active) VALUES
('director.register','permissions.director_register','platform',1),
('director.status','permissions.director_status','platform',1),
('director.reset_password','permissions.director_reset_password','platform',1),
('schools.edit','permissions.schools_edit','platform',1),
('schools.view','permissions.schools_view','platform',1),
('audit.view','permissions.audit_view','platform',1),
('subscription.manage','permissions.subscription_manage','platform',0),
('revenue.view','permissions.revenue_view','platform',0),
('usage.view','permissions.usage_view','platform',0),
('schools.data','permissions.schools_data','platform',0),
('admin.manage','permissions.admin_manage','platform',0),
('staff.create','permissions.staff_create','school',0),
('roles.assign','permissions.roles_assign','school',0),
('academic.manage','permissions.academic_manage','school',0);
CREATE TABLE IF NOT EXISTS role_permissions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 role VARCHAR(50) NOT NULL,
 permission_key VARCHAR(80) NOT NULL,
 school_id BIGINT UNSIGNED NULL,
 granted_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_role_permission(role,permission_key,school_id),
 INDEX idx_role_permission_user_scope(school_id,role),
 FOREIGN KEY(permission_key) REFERENCES permission_catalog(permission_key),
 FOREIGN KEY(school_id) REFERENCES schools(id),
 FOREIGN KEY(granted_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE users ADD INDEX idx_users_role_status(role,status);
