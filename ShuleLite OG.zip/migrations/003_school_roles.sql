CREATE TABLE IF NOT EXISTS role_catalog (
 role_name VARCHAR(50) PRIMARY KEY,
 scope ENUM('platform','school','family','individual') NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO role_catalog(role_name,scope) VALUES
('System Admin','platform'),('Sub Director','platform'),('Director','school'),('Head of School','school'),
('Admin/Account Manager','school'),('Academic Head','school'),('Examination Master','school'),('Department Head','school'),
('Teacher','school'),('HR','school'),('Head of Finance','school'),('Accountant','school'),('Discipline staff','school'),
('Secretary','school'),('Storekeeper','school'),('Procurement/inventory staff','school'),('Driver','school'),
('Route Mistress','school'),('Parent','family'),('Student','individual');
CREATE TABLE IF NOT EXISTS user_school_roles (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 school_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 role_name VARCHAR(50) NOT NULL,
 assigned_by BIGINT UNSIGNED NOT NULL,
 status ENUM('active','revoked') NOT NULL DEFAULT 'active',
 created_at DATETIME NOT NULL,
 revoked_at DATETIME NULL,
 UNIQUE KEY uq_school_user_role(school_id,user_id,role_name),
 INDEX idx_user_school_role_lookup(user_id,school_id,status),
 FOREIGN KEY(school_id) REFERENCES schools(id), FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(role_name) REFERENCES role_catalog(role_name), FOREIGN KEY(assigned_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
UPDATE permission_catalog SET active=1 WHERE permission_key IN ('staff.create','roles.assign','academic.manage');
INSERT IGNORE INTO role_permissions(role,permission_key,school_id,granted_by,created_at)
SELECT 'Director','staff.create',NULL,NULL,NOW() FROM permission_catalog WHERE permission_key='staff.create';
