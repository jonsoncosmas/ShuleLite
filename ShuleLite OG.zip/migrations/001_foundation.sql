CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role VARCHAR(50) NOT NULL,
 status ENUM('active','suspended') NOT NULL DEFAULT 'active',
 phone VARCHAR(30) NULL,
 force_password_change TINYINT(1) NOT NULL DEFAULT 0,
 session_epoch INT UNSIGNED NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS schools (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 code CHAR(9) NOT NULL UNIQUE,
 name VARCHAR(180) NOT NULL,
 region VARCHAR(120) NOT NULL,
 district VARCHAR(120) NOT NULL,
 status ENUM('active','suspended') NOT NULL DEFAULT 'active',
 created_by BIGINT UNSIGNED NOT NULL,
 created_at DATETIME NOT NULL,
 INDEX idx_schools_status(status),
 CONSTRAINT fk_schools_creator FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS school_users (
 school_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(school_id,user_id), INDEX idx_school_users_user(user_id),
 FOREIGN KEY(school_id) REFERENCES schools(id), FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS subdirector_grants (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 permission_key VARCHAR(80) NOT NULL,
 school_id BIGINT UNSIGNED NULL,
 created_by BIGINT UNSIGNED NOT NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_subdirector_grant(user_id,permission_key,school_id),
 INDEX idx_subdirector_grant_scope(school_id,user_id),
 FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(school_id) REFERENCES schools(id), FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS login_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL,
 ip_address VARCHAR(45) NOT NULL,
 attempted_at DATETIME NOT NULL,
 INDEX idx_login_user_time(username,attempted_at), INDEX idx_login_ip_time(ip_address,attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS audit_log (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 actor_user_id BIGINT UNSIGNED NULL,
 action VARCHAR(100) NOT NULL,
 target_type VARCHAR(80) NOT NULL,
 target_id BIGINT UNSIGNED NULL,
 changes_json JSON NOT NULL,
 ip_address VARCHAR(45) NULL,
 created_at DATETIME NOT NULL,
 INDEX idx_audit_time(created_at), INDEX idx_audit_actor(actor_user_id,created_at),
 FOREIGN KEY(actor_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
