INSERT IGNORE INTO role_catalog(role_name,scope,active) VALUES('Sub System Admin','platform',1);
UPDATE role_catalog SET scope='school',active=1 WHERE role_name='Sub Director';

CREATE TABLE IF NOT EXISTS subsystemadmin_grants (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 permission_key VARCHAR(80) NOT NULL,
 school_id BIGINT UNSIGNED NULL,
 created_by BIGINT UNSIGNED NOT NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_subsystemadmin_grant(user_id,permission_key,school_id),
 INDEX idx_subsystemadmin_grant_scope(school_id,user_id),
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(permission_key) REFERENCES permission_catalog(permission_key),
 FOREIGN KEY(school_id) REFERENCES schools(id),
 FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO subsystemadmin_grants(user_id,permission_key,school_id,created_by,created_at)
SELECT user_id,permission_key,school_id,created_by,created_at FROM subdirector_grants;

INSERT IGNORE INTO role_permissions(role,permission_key,school_id,granted_by,created_at)
SELECT 'Sub System Admin',permission_key,school_id,granted_by,created_at
FROM role_permissions WHERE role='Sub Director';
DELETE FROM role_permissions WHERE role='Sub Director';

UPDATE users SET role='Sub System Admin' WHERE role='Sub Director';
