(() => {
  const page = window.shuleLitePage;
  const text = window.shuleLiteText;
  if (!page || !text) return;
  const records = document.querySelector('#records');
  const status = document.querySelector('#status');
  const form = document.querySelector('#create-form');
  let csrf = '';
  const safe = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  async function request(url, options = {}) {
    const response = await fetch(url, { ...options, headers: { 'Content-Type':'application/json', 'X-CSRF-Token':csrf, ...(options.headers || {}) } });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || text.error);
    return body;
  }
  function showMessage(message, isError = false) {
    status.textContent = message; status.className = `notice${isError ? ' error' : ''}`;
  }
  function render(items) {
    if (!items.length) { records.textContent = text.empty; return; }
    records.innerHTML = items.map(row => `<article class="record-row"><div><strong>${safe(row.name || row.username || row.code)}</strong><p>${safe(page === 'schools' ? `${row.code} · ${row.region}, ${row.district}` : row.status)}</p></div>${page === 'schools' ? `<span class="badge">${safe(row.status)}</span>` : `<div class="record-actions"><button type="button" data-action="reset" data-id="${safe(row.id)}">${safe(text.reset)}</button><button type="button" data-action="status" data-id="${safe(row.id)}" data-status="${row.status === 'active' ? 'suspended' : 'active'}">${safe(row.status === 'active' ? text.suspend : text.activate)}</button></div>`}</article>`).join('');
  }
  async function load() {
    records.textContent = text.loading;
    try { const data = await request(`/api/${page}`); render(page === 'schools' ? data.schools : data.directors); }
    catch (error) { records.textContent = error.message; }
  }
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const button = form.querySelector('button'); button.disabled = true;
    const data = Object.fromEntries(new FormData(form));
    try {
      const result = await request(`/api/${page}`, { method:'POST', body:JSON.stringify(data) });
      form.reset();
      if (result.temporary_password) window.alert(`${text.password}\n${result.temporary_password}`);
      showMessage(text.saved); await load();
    } catch (error) { showMessage(error.message, true); }
    finally { button.disabled = false; }
  });
  records.addEventListener('click', async event => {
    const button = event.target.closest('button[data-action]'); if (!button) return;
    button.disabled = true;
    try {
      const id = encodeURIComponent(button.dataset.id);
      if (button.dataset.action === 'reset') {
        const result = await request(`/api/directors/${id}/reset-password`, { method:'POST', body:'{}' });
        window.alert(`${text.password}\n${result.temporary_password}`);
      } else await request(`/api/directors/${id}/status`, { method:'POST', body:JSON.stringify({status:button.dataset.status}) });
      showMessage(text.saved); await load();
    } catch (error) { showMessage(error.message, true); button.disabled = false; }
  });
  request('/api/session').then(data => { csrf = data.csrf; load(); }).catch(error => { records.textContent = error.message; form.hidden = true; });
})();
