(() => {
  const config = window.shuleLiteUserAdmin;
  if (!config) return;
  const style=document.createElement('link');style.rel='stylesheet';style.href='/assets/user-admin.css';document.head.append(style);
  const text = config.text;
  let csrf = '';
  const request = async (url, options = {}) => {
    const response = await fetch(url, { ...options, headers: { 'Content-Type':'application/json', 'X-CSRF-Token':csrf, ...(options.headers || {}) } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || text.error);
    return data;
  };
  const credential = (node, data) => {
    node.replaceChildren();
    const heading=document.createElement('strong'); heading.textContent=text.created;
    const username=document.createElement('p'); username.textContent=data.username || '';
    const password=document.createElement('p'); password.textContent=`${text.password}: ${data.temporary_password}`;
    node.append(heading,username,password);
  };
  const bindCreate = (formId, endpoint, outputId) => {
    const form=document.getElementById(formId); if(!form)return;
    form.addEventListener('submit',async event=>{
      event.preventDefault(); const button=form.querySelector('button'); button.disabled=true;
      try { const result=await request(endpoint,{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(form)))});credential(document.getElementById(outputId),{username:result.director?.username||result.sub_system_admin?.username||result.user?.username,temporary_password:result.temporary_password});form.reset();if(formId==='sub-director-form')await loadSubDirectors(); }
      catch(error){const output=document.getElementById(outputId);output.textContent=error.message;output.classList.add('error')}
      finally{button.disabled=false}
    });
  };
  async function init(){
    const session=await request('/api/session');csrf=session.csrf;
    if(config.platform){bindCreate('director-form','/api/directors','director-result');bindCreate('sub-director-form','/api/sub-system-admins','sub-director-result');await loadSubDirectors()}
    if(config.schoolStaff)await loadStaffOptions();
  }
  let catalog=[], schools=[];
  async function loadSubDirectors(){
    const data=await request('/api/sub-system-admins');catalog=data.permissions;schools=data.schools;
    const select=document.getElementById('sub-director-select');const keep=select.value;
    select.innerHTML=`<option value="">${select.options[0]?.textContent||''}</option>`+data.sub_system_admins.map(u=>`<option value="${u.id}">${escapeHtml(u.username)} · ${escapeHtml(u.status)}</option>`).join('');
    if(keep)select.value=keep;select.onchange=()=>loadGrantChoices().catch(showGrantError);
    if(select.value)await loadGrantChoices();
  }
  const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  async function loadGrantChoices(){
    const id=document.getElementById('sub-director-select').value;const list=document.getElementById('grant-list');const save=document.getElementById('save-grants');
    list.replaceChildren();save.disabled=!id;if(!id)return;
    const current=await request(`/api/sub-system-admins/${encodeURIComponent(id)}/grants`);const granted=new Set(current.grants.map(g=>`${g.permission_key}:${g.school_id??'platform'}`));
    for(const permission of catalog){
      const field=document.createElement('fieldset');const legend=document.createElement('legend');legend.textContent=permission.permission_key;field.append(legend);
      const scopes=permission.scope==='platform'?[null]:schools;
      for(const school of scopes){const label=document.createElement('label');label.className='grant-option';const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.disabled=!Number(permission.active);checkbox.value=JSON.stringify({permission:permission.permission_key,school_id:school?Number(school.id):null});checkbox.checked=granted.has(`${permission.permission_key}:${school?school.id:'platform'}`);const caption=document.createElement('span');caption.textContent=school?`${school.code} · ${school.name}`:'All assigned platform scope';label.append(checkbox,caption);field.append(label)}list.append(field)
    }
    save.onclick=saveGrants;
  }
  async function saveGrants(){
    const id=document.getElementById('sub-director-select').value;const save=document.getElementById('save-grants');save.disabled=true;
    const grants=[...document.querySelectorAll('#grant-list input:checked')].map(item=>JSON.parse(item.value));
    try{await request(`/api/sub-system-admins/${encodeURIComponent(id)}/grants`,{method:'PUT',body:JSON.stringify({grants})});const status=document.getElementById('grant-status');status.textContent=text.saved;status.classList.remove('error')}
    catch(error){showGrantError(error)}finally{save.disabled=false}
  }
  function showGrantError(error){const status=document.getElementById('grant-status');status.textContent=error.message;status.classList.add('error')}
  async function loadStaffOptions(){
    const schoolUrl=config.platform?'/api/schools?for=staff':'/api/schools?for=staff';
    const [schoolData,roleData]=await Promise.all([request(schoolUrl),request('/api/school-roles')]);
    const school=document.getElementById('staff-school'),role=document.getElementById('staff-role');
    for(const item of schoolData.schools){const option=document.createElement('option');option.value=item.id;option.textContent=`${item.code} · ${item.name}`;school.append(option)}
    for(const item of roleData.roles){const option=document.createElement('option');option.value=item;option.textContent=item;role.append(option)}
    document.getElementById('staff-form').addEventListener('submit',async event=>{event.preventDefault();const form=event.currentTarget,button=form.querySelector('button');button.disabled=true;try{const result=await request('/api/staff',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(form)))});credential(document.getElementById('staff-result'),{username:result.user.username,temporary_password:result.temporary_password});form.reset()}catch(error){const out=document.getElementById('staff-result');out.textContent=error.message;out.classList.add('error')}finally{button.disabled=false}})
  }
  init().catch(error=>{document.getElementById('page-status').textContent=error.message;document.getElementById('page-status').classList.add('error')});
})();
