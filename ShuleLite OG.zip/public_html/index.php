<?php
declare(strict_types=1);
require dirname(__DIR__) . '/config/bootstrap.php';

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
require_once dirname(__DIR__) . '/src/Workflow.php';
$workflow = new Workflow($pdo);
if ($workflow->dispatch($path)) exit;
if ($path === '/health') { header('Content-Type: application/json'); echo json_encode(['status'=>'ok','app'=>'ShuleLite']); exit; }
if ($path === '/logout') { session_unset(); session_destroy(); header('Location: /login'); exit; }
if ($path === '/login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $username = trim((string)($_POST['username'] ?? '')); $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $q = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE username = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)'); $q->execute([$username]);
    $byUser = (int)$q->fetchColumn();
    $q = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)'); $q->execute([$ip]);
    $byIp = (int)$q->fetchColumn();
    $q = $pdo->prepare('SELECT id,password_hash,role,status,force_password_change,session_epoch FROM users WHERE username = ?'); $q->execute([$username]); $user = $q->fetch();
    if ($byUser < 5 && $byIp < 30 && $user && $user['status'] === 'active' && password_verify((string)($_POST['password'] ?? ''), $user['password_hash'])) {
        session_regenerate_id(true); $_SESSION['user_id']=(int)$user['id']; $_SESSION['role']=$user['role']; $_SESSION['session_epoch']=(int)$user['session_epoch']; $_SESSION['force_password_change']=(bool)$user['force_password_change'];
        $pdo->prepare('DELETE FROM login_attempts WHERE username = ?')->execute([$username]); header('Location: /'); exit;
    }
    $q = $pdo->prepare('INSERT INTO login_attempts(username,ip_address,attempted_at) VALUES(?,?,NOW())'); $q->execute([$username,$ip]);
    $loginError = true;
}
if ($path === '/login') { $csrf = csrf_token(); require dirname(__DIR__).'/templates/login.php'; exit; }
if ($path === '/change-password') {
    require_login();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_verify();
        $password = (string)($_POST['password'] ?? '');
        if (strlen($password) >= 12 && hash_equals($password, (string)($_POST['confirm'] ?? ''))) {
            $pdo->prepare('UPDATE users SET password_hash=?,force_password_change=0,session_epoch=session_epoch+1,updated_at=NOW() WHERE id=?')->execute([password_hash($password,PASSWORD_DEFAULT),$_SESSION['user_id']]);
            audit($pdo,'password.change','user',(int)$_SESSION['user_id']); $_SESSION['session_epoch']=(int)($_SESSION['session_epoch']??0)+1; $_SESSION['force_password_change']=false; header('Location: /'); exit;
        }
        $passwordError = true;
    }
    $csrf=csrf_token(); require dirname(__DIR__).'/templates/change-password.php'; exit;
}
if (empty($_SESSION['user_id'])) { header('Location: /login'); exit; }
$q=$pdo->prepare('SELECT role,status,session_epoch,force_password_change FROM users WHERE id=?'); $q->execute([$_SESSION['user_id']]); $current=$q->fetch();
if (!$current || $current['status']!=='active' || (int)$current['session_epoch'] !== (int)($_SESSION['session_epoch'] ?? -1)) { session_destroy(); header('Location: /login'); exit; }
$_SESSION['role']=$current['role']; $_SESSION['force_password_change']=(bool)$current['force_password_change']; require_login();
if ($path === '/admin/users') { require dirname(__DIR__).'/templates/account-admin.php'; exit; }
if ($path === '/admin/school-managers') {
    if ($_SESSION['role'] !== 'Director') { http_response_code(403); exit('Only a Director can manage School Manager accounts.'); }
    require dirname(__DIR__).'/templates/school-managers.php'; exit;
}
if ($path === '/schools' || $path === '/admin/directors') {
    $managementPage = $path === '/schools' ? 'schools' : 'directors';
    require dirname(__DIR__).'/templates/management.php'; exit;
}
if ($path === '/admin/audit') {
    $allowed = $_SESSION['role'] === 'System Admin';
    if ($_SESSION['role'] === 'Sub System Admin') { $check=$pdo->prepare("SELECT 1 FROM subsystemadmin_grants g JOIN permission_catalog c ON c.permission_key=g.permission_key WHERE g.user_id=? AND g.permission_key='audit.view' AND c.active=1 LIMIT 1"); $check->execute([$_SESSION['user_id']]); $allowed=(bool)$check->fetchColumn(); }
    if (!$allowed) { http_response_code(403); exit('You do not have permission to view this page.'); }
    $q=$pdo->query('SELECT id,actor_user_id,action,target_type,target_id,created_at FROM audit_log ORDER BY id DESC LIMIT 100'); $auditRows=$q->fetchAll();
    require dirname(__DIR__).'/templates/audit.php'; exit;
}
require dirname(__DIR__).'/templates/dashboard.php';
