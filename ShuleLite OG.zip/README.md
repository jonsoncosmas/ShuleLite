# ShuleLite

ShuleLite is a PHP and MariaDB school operating system for SomaSpace Africa.

Local setup and manual verification instructions are maintained in [DEV.md](DEV.md).
