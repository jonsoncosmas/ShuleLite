<?php
declare(strict_types=1);

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_verify(): void
{
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_POST['_csrf'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) { http_response_code(419); exit('Your session expired. Refresh and try again.'); }
}
function require_login(): void
{
    if (empty($_SESSION['user_id'])) { http_response_code(401); exit('Please sign in to continue.'); }
    if (!empty($_SESSION['force_password_change']) && !str_ends_with($_SERVER['REQUEST_URI'] ?? '', '/change-password')) { header('Location: /change-password'); exit; }
}
function require_role(PDO $pdo, array $roles): void
{
    require_login();
    $q = $pdo->prepare('SELECT role FROM users WHERE id = ? AND status = ?');
    $q->execute([$_SESSION['user_id'], 'active']);
    $role = $q->fetchColumn();
    if (!$role || !in_array($role, $roles, true)) { http_response_code(403); exit('You do not have permission to view this page.'); }
    $_SESSION['role'] = $role;
}
function audit(PDO $pdo, string $action, string $targetType, ?int $targetId = null, array $changes = []): void
{
    $stmt = $pdo->prepare('INSERT INTO audit_log (actor_user_id, action, target_type, target_id, changes_json, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())');
    $stmt->execute([$_SESSION['user_id'] ?? null, $action, $targetType, $targetId, json_encode($changes, JSON_THROW_ON_ERROR), $_SERVER['REMOTE_ADDR'] ?? null]);
}
