<?php
declare(strict_types=1);
$messages = require dirname(__DIR__) . '/lang/en.php';
function t(string $key, array $replace = []): string
{
    global $messages;
    $value = $messages[$key] ?? $key;
    foreach ($replace as $name => $content) $value = str_replace('{' . $name . '}', (string) $content, $value);
    return $value;
}
