<?php
declare(strict_types=1);

final class Workflow
{
    public function __construct(private PDO $pdo) {}

    public function dispatch(string $path): bool
    {
        if (!str_starts_with($path, '/api/')) return false;
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        try {
            if ($path === '/api/session' && $_SERVER['REQUEST_METHOD'] === 'GET') {
                require_login();
                $this->ok(['role' => $_SESSION['role'], 'csrf' => csrf_token()]);
            }
            if (empty($_SESSION['user_id'])) $this->fail(401, 'Sign in to continue.');
            if ($_SERVER['REQUEST_METHOD'] !== 'GET') csrf_verify();
            $this->checkCurrentSession();
            $method = $_SERVER['REQUEST_METHOD'];
            if ($path === '/api/schools' && $method === 'GET') $this->listSchools();
            if ($path === '/api/schools' && $method === 'POST') $this->createSchool();
            if (preg_match('~^/api/schools/(\d+)$~', $path, $m) && $method === 'PATCH') $this->updateSchool((int)$m[1]);
            if ($path === '/api/directors' && $method === 'GET') $this->listDirectors();
            if ($path === '/api/directors' && $method === 'POST') $this->createDirector();
            if (preg_match('~^/api/directors/(\d+)/(status|reset-password)$~', $path, $m) && $method === 'POST') {
                if ($m[2] === 'status') $this->changeDirectorStatus((int)$m[1]);
                $this->resetDirectorPassword((int)$m[1]);
            }
            if ($path === '/api/sub-system-admins' && $method === 'GET') $this->listSubDirectors();
            if ($path === '/api/sub-system-admins' && $method === 'POST') $this->createSubDirector();
            if (preg_match('~^/api/sub-system-admins/(\d+)/grants$~', $path, $m) && $method === 'GET') $this->getSubDirectorGrants((int)$m[1]);
            if (preg_match('~^/api/sub-system-admins/(\d+)/grants$~', $path, $m) && $method === 'PUT') $this->setSubDirectorGrants((int)$m[1]);
            if ($path === '/api/staff' && $method === 'POST') $this->createSchoolStaff();
            if ($path === '/api/school-roles' && $method === 'GET') $this->listSchoolRoles();
            if ($path === '/api/school-managers' && $method === 'GET') $this->listSchoolManagers();
            if ($path === '/api/school-managers' && $method === 'POST') $this->createSchoolManager();
            $this->fail(404, 'That workspace action was not found.');
        } catch (JsonResponse $response) {
            http_response_code($response->status);
            echo json_encode($response->payload, JSON_INVALID_UTF8_SUBSTITUTE);
            return true;
        } catch (Throwable $error) {
            error_log('ShuleLite workflow failure: ' . $error->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'We could not save that change. Please try again.']);
            return true;
        }
    }

    private function checkCurrentSession(): void
    {
        $q = $this->pdo->prepare('SELECT role,status,session_epoch,force_password_change FROM users WHERE id=?');
        $q->execute([$_SESSION['user_id']]); $user = $q->fetch();
        if (!$user || $user['status'] !== 'active' || (int)$user['session_epoch'] !== (int)($_SESSION['session_epoch'] ?? -1)) $this->fail(401, 'Your session ended. Sign in again.');
        $_SESSION['role'] = $user['role']; $_SESSION['force_password_change'] = (bool)$user['force_password_change'];
        if ($_SESSION['force_password_change']) $this->fail(403, 'Change your password before continuing.');
    }

    private function allowed(string $permission, ?int $schoolId = null): bool
    {
        $role = $_SESSION['role'];
        if ($role === 'System Admin') return true;
        if ($role === 'Director' && $permission === 'schools.edit' && $schoolId !== null) {
            $q=$this->pdo->prepare('SELECT 1 FROM school_users su JOIN schools s ON s.id=su.school_id WHERE su.school_id=? AND su.user_id=? AND s.created_by=? LIMIT 1');
            $q->execute([$schoolId,$_SESSION['user_id'],$_SESSION['user_id']]); return (bool)$q->fetchColumn();
        }
        if ($role === 'Director' && $permission === 'staff.create' && $schoolId !== null) {
            $q=$this->pdo->prepare('SELECT 1 FROM school_users su JOIN schools s ON s.id=su.school_id WHERE su.school_id=? AND su.user_id=? AND s.created_by=? LIMIT 1');
            $q->execute([$schoolId,$_SESSION['user_id'],$_SESSION['user_id']]); if(!$q->fetchColumn()) return false;
        }
        $q=$this->pdo->prepare('SELECT 1 FROM role_permissions rp JOIN permission_catalog pc ON pc.permission_key=rp.permission_key WHERE rp.role=? AND rp.permission_key=? AND pc.active=1 AND (rp.school_id IS NULL OR rp.school_id=?) LIMIT 1');
        $q->execute([$role,$permission,$schoolId]); if ($q->fetchColumn()) return true;
        if ($role === 'Sub System Admin') {
            $q=$this->pdo->prepare('SELECT 1 FROM subsystemadmin_grants g JOIN permission_catalog pc ON pc.permission_key=g.permission_key WHERE g.user_id=? AND g.permission_key=? AND pc.active=1 AND (g.school_id IS NULL OR g.school_id=?) LIMIT 1');
            $q->execute([$_SESSION['user_id'],$permission,$schoolId]); return (bool)$q->fetchColumn();
        }
        if ($role === 'Sub Director' && $schoolId !== null) {
            $q=$this->pdo->prepare("SELECT 1 FROM user_school_roles WHERE user_id=? AND school_id=? AND role_name='Sub Director' AND status='active' LIMIT 1");
            $q->execute([$_SESSION['user_id'],$schoolId]); if(!$q->fetchColumn()) return false;
        }
        return false;
    }

    private function demand(string $permission, ?int $schoolId = null): void
    { if (!$this->allowed($permission,$schoolId)) $this->fail(403,'You do not have permission to do that.'); }

    private function listSchools(): never
    {
        $role=$_SESSION['role'];
        if ($role==='System Admin') $rows=$this->pdo->query('SELECT id,code,name,region,district,status FROM schools ORDER BY name')->fetchAll();
        elseif ($role==='Director') { $q=$this->pdo->prepare('SELECT s.id,s.code,s.name,s.region,s.district,s.status FROM schools s JOIN school_users su ON su.school_id=s.id WHERE su.user_id=? AND s.created_by=? ORDER BY s.name'); $q->execute([$_SESSION['user_id'],$_SESSION['user_id']]); $rows=$q->fetchAll(); }
        elseif ($role==='Sub Director') { $q=$this->pdo->prepare("SELECT s.id,s.code,s.name,s.region,s.district,s.status FROM schools s JOIN user_school_roles r ON r.school_id=s.id WHERE r.user_id=? AND r.role_name='Sub Director' AND r.status='active' ORDER BY s.name"); $q->execute([$_SESSION['user_id']]); $rows=$q->fetchAll(); }
        else {
            if (($_GET['for'] ?? '') === 'staff') {
                $q=$this->pdo->prepare("SELECT DISTINCT s.id,s.code,s.name,s.region,s.district,s.status FROM schools s JOIN subsystemadmin_grants g ON g.school_id=s.id WHERE g.user_id=? AND g.permission_key='staff.create' ORDER BY s.name"); $q->execute([$_SESSION['user_id']]); $rows=$q->fetchAll();
                $this->ok(['schools'=>$rows]);
            }
            $this->demand('schools.view');
            $q=$this->pdo->prepare("SELECT 1 FROM subsystemadmin_grants WHERE user_id=? AND permission_key='schools.view' AND school_id IS NULL"); $q->execute([$_SESSION['user_id']]);
            if($q->fetchColumn()) $rows=$this->pdo->query('SELECT id,code,name,region,district,status FROM schools ORDER BY name')->fetchAll();
            else { $q=$this->pdo->prepare("SELECT DISTINCT s.id,s.code,s.name,s.region,s.district,s.status FROM schools s JOIN subsystemadmin_grants g ON g.school_id=s.id WHERE g.user_id=? AND g.permission_key='schools.view' ORDER BY s.name"); $q->execute([$_SESSION['user_id']]); $rows=$q->fetchAll(); }
        }
        $this->ok(['schools'=>$rows]);
    }

    private function createSchool(): never
    {
        if (!in_array($_SESSION['role'],['Director','Sub Director'],true)) $this->fail(403,'You do not have permission to add a school.');
        if ($_SESSION['role']==='Sub Director') $this->demand('schools.edit');
        $data=$this->input(); $name=$this->text($data,'name',180); $region=$this->text($data,'region',120); $district=$this->text($data,'district',120);
        $this->pdo->beginTransaction();
        try {
            $code='SL-'.strtoupper(bin2hex(random_bytes(3)));
            $q=$this->pdo->prepare("INSERT INTO schools(code,name,region,district,status,created_by,created_at) VALUES(?,?,?,?, 'active', ?, NOW())");
            $q->execute([$code,$name,$region,$district,$_SESSION['user_id']]); $id=(int)$this->pdo->lastInsertId();
            $q=$this->pdo->prepare('INSERT INTO school_users(school_id,user_id,created_at) VALUES(?,?,NOW())'); $q->execute([$id,$_SESSION['user_id']]);
            audit($this->pdo,'school.create','school',$id,['code'=>$code,'name'=>$name]); $this->pdo->commit();
            $this->ok(['school'=>['id'=>$id,'code'=>$code,'name'=>$name,'region'=>$region,'district'=>$district,'status'=>'active']],201);
        } catch(Throwable $e) { if($this->pdo->inTransaction())$this->pdo->rollBack(); throw $e; }
    }

    private function updateSchool(int $id): never
    {
        $this->demand('schools.edit',$id); $data=$this->input();
        if($_SESSION['role']==='System Admin' && (array_diff(array_keys($data),['status']) || !isset($data['status']))) $this->fail(403,'System Admin access to school records is read-only; only school status can be changed here.');
        if (isset($data['status']) && $_SESSION['role']==='Director') $this->fail(403,'Directors cannot change a school status.');
        $fields=[];$values=[];
        foreach(['name'=>180,'region'=>120,'district'=>120] as $field=>$max) if(array_key_exists($field,$data)){$fields[]="$field=?";$values[]=$this->text($data,$field,$max);}
        if(isset($data['status'])){if(!in_array($data['status'],['active','suspended'],true))$this->fail(422,'Choose active or suspended.');$fields[]='status=?';$values[]=$data['status'];}
        if(!$fields)$this->fail(422,'Add at least one school detail to update.');
        $values[]=$id;$q=$this->pdo->prepare('UPDATE schools SET '.implode(',',$fields).' WHERE id=?');$q->execute($values);
        audit($this->pdo,'school.update','school',$id,$data);$this->ok(['saved'=>true]);
    }

    private function listDirectors(): never
    { $this->demand('director.register');$rows=$this->pdo->query("SELECT id,username,status,created_at FROM users WHERE role='Director' ORDER BY id DESC LIMIT 200")->fetchAll();$this->ok(['directors'=>$rows]); }

    private function createDirector(): never
    {
        $this->demand('director.register');$d=$this->input();$username=$this->text($d,'username',80);
        if(!preg_match('/^[a-zA-Z0-9._-]{3,80}$/',$username))$this->fail(422,'Use 3–80 letters, numbers, dots, underscores or hyphens for the username.');
        $temporary=bin2hex(random_bytes(6));
        try{$q=$this->pdo->prepare("INSERT INTO users(username,password_hash,role,status,force_password_change,session_epoch,created_at) VALUES(?,?, 'Director','active',1,0,NOW())");$q->execute([$username,password_hash($temporary,PASSWORD_DEFAULT)]);$id=(int)$this->pdo->lastInsertId();audit($this->pdo,'director.create','user',$id,['username'=>$username]);$this->ok(['director'=>['id'=>$id,'username'=>$username],'temporary_password'=>$temporary],201);}
        catch(PDOException $e){if($e->getCode()==='23000')$this->fail(409,'That username is already in use.');throw $e;}
    }

    private function changeDirectorStatus(int $id): never
    { $this->demand('director.status');$d=$this->input();$status=$d['status']??'';if(!in_array($status,['active','suspended'],true))$this->fail(422,'Choose active or suspended.');$q=$this->pdo->prepare("UPDATE users SET status=?,session_epoch=session_epoch+1,updated_at=NOW() WHERE id=? AND role='Director'");$q->execute([$status,$id]);if(!$q->rowCount())$this->fail(404,'Director not found.');audit($this->pdo,'director.status','user',$id,['status'=>$status]);$this->ok(['saved'=>true]); }

    private function resetDirectorPassword(int $id): never
    { $this->demand('director.reset_password');$temporary=bin2hex(random_bytes(6));$q=$this->pdo->prepare("UPDATE users SET password_hash=?,force_password_change=1,session_epoch=session_epoch+1,updated_at=NOW() WHERE id=? AND role='Director'");$q->execute([password_hash($temporary,PASSWORD_DEFAULT),$id]);if(!$q->rowCount())$this->fail(404,'Director not found.');audit($this->pdo,'director.password_reset','user',$id);$this->ok(['temporary_password'=>$temporary]); }

    private function listSubDirectors(): never
    { $this->demand('admin.manage');$rows=$this->pdo->query("SELECT id,username,status,created_at FROM users WHERE role='Sub System Admin' ORDER BY id DESC LIMIT 200")->fetchAll();$catalog=$this->pdo->query('SELECT permission_key,scope,active FROM permission_catalog ORDER BY permission_key')->fetchAll();$schools=$this->pdo->query('SELECT id,code,name FROM schools ORDER BY name')->fetchAll();$this->ok(['sub_system_admins'=>$rows,'permissions'=>$catalog,'schools'=>$schools]); }

    private function getSubDirectorGrants(int $id): never
    { if($_SESSION['role']!=='System Admin')$this->fail(403,'Only a System Admin can view delegated platform grants.');$q=$this->pdo->prepare("SELECT id FROM users WHERE id=? AND role='Sub System Admin'");$q->execute([$id]);if(!$q->fetchColumn())$this->fail(404,'Sub System Admin not found.');$q=$this->pdo->prepare('SELECT permission_key,school_id FROM subsystemadmin_grants WHERE user_id=? ORDER BY permission_key,school_id');$q->execute([$id]);$this->ok(['grants'=>$q->fetchAll()]); }

    private function createSubDirector(): never
    { if($_SESSION['role']!=='System Admin')$this->fail(403,'Only a System Admin can create a Sub System Admin.');$d=$this->input();$username=$this->text($d,'username',80);if(!preg_match('/^[a-zA-Z0-9._-]{3,80}$/',$username))$this->fail(422,'Use 3–80 letters, numbers, dots, underscores or hyphens for the username.');$temp=bin2hex(random_bytes(6));try{$q=$this->pdo->prepare("INSERT INTO users(username,password_hash,role,status,force_password_change,session_epoch,created_at) VALUES(?,?,'Sub System Admin','active',1,0,NOW())");$q->execute([$username,password_hash($temp,PASSWORD_DEFAULT)]);$id=(int)$this->pdo->lastInsertId();audit($this->pdo,'subsystemadmin.create','user',$id,['username'=>$username]);$this->ok(['sub_system_admin'=>['id'=>$id,'username'=>$username],'temporary_password'=>$temp],201);}catch(PDOException $e){if($e->getCode()==='23000')$this->fail(409,'That username is already in use.');throw $e;} }

    private function setSubDirectorGrants(int $id): never
    { if($_SESSION['role']!=='System Admin')$this->fail(403,'Only a System Admin can edit delegated platform grants.');$d=$this->input();$grants=$d['grants']??null;if(!is_array($grants))$this->fail(422,'Choose a permission list.');$q=$this->pdo->prepare("SELECT id FROM users WHERE id=? AND role='Sub System Admin'");$q->execute([$id]);if(!$q->fetchColumn())$this->fail(404,'Sub System Admin not found.');$this->pdo->beginTransaction();try{$this->pdo->prepare('DELETE FROM subsystemadmin_grants WHERE user_id=?')->execute([$id]);$ins=$this->pdo->prepare('INSERT INTO subsystemadmin_grants(user_id,permission_key,school_id,created_by,created_at) SELECT ?,permission_key,?, ?,NOW() FROM permission_catalog WHERE permission_key=? AND active=1 AND ((scope=\'platform\' AND ? IS NULL) OR (scope=\'school\' AND ? IS NOT NULL))');foreach($grants as $g){if(!is_array($g)||!array_key_exists('permission',$g)||!array_key_exists('school_id',$g))$this->fail(422,'A grant entry is incomplete.');$school=$g['school_id']===null?null:(int)$g['school_id'];$ins->execute([$id,$school,$_SESSION['user_id'],(string)$g['permission'],$school,$school]);if(!$ins->rowCount())$this->fail(422,'A selected permission or scope is not available.');}$this->pdo->commit();audit($this->pdo,'subsystemadmin.grants','user',$id,['count'=>count($grants)]);$this->ok(['saved'=>true]);}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;} }

    private function listSchoolRoles(): never
    { $rows=$this->pdo->query("SELECT role_name FROM role_catalog WHERE scope='school' AND active=1 ORDER BY role_name")->fetchAll(PDO::FETCH_COLUMN);$this->ok(['roles'=>$rows]); }

    private function listSchoolManagers(): never
    {
        if($_SESSION['role']!=='Director')$this->fail(403,'Only a Director can manage School Manager accounts.');
        $q=$this->pdo->prepare("SELECT DISTINCT u.id,u.username,u.status,s.id AS school_id,s.code AS school_code,s.name AS school_name FROM users u JOIN user_school_roles r ON r.user_id=u.id AND r.role_name='Sub Director' AND r.status='active' JOIN schools s ON s.id=r.school_id WHERE u.role='Sub Director' AND s.created_by=? ORDER BY s.name,u.username");$q->execute([$_SESSION['user_id']]);$rows=$q->fetchAll();
        $this->ok(['managers'=>$rows]);
    }

    private function createSchoolManager(): never
    {
        if($_SESSION['role']!=='Director')$this->fail(403,'Only a Director can create School Manager accounts.');
        $data=$this->input();$schoolId=(int)($data['school_id']??0);$username=$this->text($data,'username',80);
        if($schoolId<1)$this->fail(422,'Choose a school.');
        if(!preg_match('/^[a-zA-Z0-9._-]{3,80}$/',$username))$this->fail(422,'Use 3–80 letters, numbers, dots, underscores or hyphens for the username.');
        $q=$this->pdo->prepare("SELECT id FROM schools WHERE id=? AND created_by=? AND status='active'");$q->execute([$schoolId,$_SESSION['user_id']]);if(!$q->fetchColumn())$this->fail(404,'Choose one of your active schools.');
        $temporary=bin2hex(random_bytes(8));$this->pdo->beginTransaction();
        try{
            $q=$this->pdo->prepare("INSERT INTO users(username,password_hash,role,status,force_password_change,session_epoch,created_at) VALUES(?,?,'Sub Director','active',1,0,NOW())");$q->execute([$username,password_hash($temporary,PASSWORD_DEFAULT)]);$userId=(int)$this->pdo->lastInsertId();
            $q=$this->pdo->prepare('INSERT INTO school_users(school_id,user_id,created_at) VALUES(?,?,NOW())');$q->execute([$schoolId,$userId]);
            $q=$this->pdo->prepare("INSERT INTO user_school_roles(school_id,user_id,role_name,assigned_by,status,created_at) VALUES(?,?,'Sub Director',?,'active',NOW())");$q->execute([$schoolId,$userId,$_SESSION['user_id']]);
            audit($this->pdo,'school_manager.create','user',$userId,['school_id'=>$schoolId,'username'=>$username]);$this->pdo->commit();
            $this->ok(['manager'=>['id'=>$userId,'username'=>$username,'school_id'=>$schoolId],'temporary_password'=>$temporary],201);
        }catch(PDOException $error){if($this->pdo->inTransaction())$this->pdo->rollBack();if($error->getCode()==='23000')$this->fail(409,'That username is already in use.');throw $error;}
        catch(Throwable $error){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $error;}
    }

    private function createSchoolStaff(): never
    {
        if(!in_array($_SESSION['role'],['Director','Sub Director','Sub System Admin'],true))$this->fail(403,'Only a school Director, School Manager or granted Sub System Admin can create school staff.');
        $d=$this->input();$schoolId=(int)($d['school_id']??0);$role=$this->text($d,'role',50);$username=$this->text($d,'username',80);
        if($schoolId<1)$this->fail(422,'Choose a school.');
        if(in_array($role,['System Admin','Sub Director','Director'],true))$this->fail(403,'This account type cannot be created from school staff management.');
        $this->demand('staff.create',$schoolId);
        $this->demand('roles.assign',$schoolId);
        $q=$this->pdo->prepare("SELECT 1 FROM role_catalog WHERE role_name=? AND scope='school' AND active=1");$q->execute([$role]);if(!$q->fetchColumn())$this->fail(422,'Choose an available school role.');
        if(!preg_match('/^[a-zA-Z0-9._-]{3,80}$/',$username))$this->fail(422,'Use 3–80 letters, numbers, dots, underscores or hyphens for the username.');
        $temporary=bin2hex(random_bytes(6));$this->pdo->beginTransaction();
        try {
            $q=$this->pdo->prepare("INSERT INTO users(username,password_hash,role,status,force_password_change,session_epoch,created_at) VALUES(?,?,?,'active',1,0,NOW())");$q->execute([$username,password_hash($temporary,PASSWORD_DEFAULT),$role]);$userId=(int)$this->pdo->lastInsertId();
            $q=$this->pdo->prepare('INSERT INTO school_users(school_id,user_id,created_at) VALUES(?,?,NOW())');$q->execute([$schoolId,$userId]);
            $q=$this->pdo->prepare("INSERT INTO user_school_roles(school_id,user_id,role_name,assigned_by,status,created_at) VALUES(?,?,?,?,'active',NOW())");$q->execute([$schoolId,$userId,$role,$_SESSION['user_id']]);
            audit($this->pdo,'staff.create','user',$userId,['school_id'=>$schoolId,'role'=>$role]);$this->pdo->commit();$this->ok(['user'=>['id'=>$userId,'username'=>$username,'role'=>$role],'temporary_password'=>$temporary],201);
        } catch(PDOException $e) { if($this->pdo->inTransaction())$this->pdo->rollBack();if($e->getCode()==='23000')$this->fail(409,'That username or school role is already in use.');throw $e; }
        catch(Throwable $e) { if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e; }
    }

    private function input(): array
    { $raw=file_get_contents('php://input');$data=json_decode($raw?:'{}',true);if(!is_array($data))$this->fail(400,'The request could not be read.');return $data; }
    private function text(array $data,string $key,int $max): string
    { $value=trim((string)($data[$key]??''));if($value===''||mb_strlen($value)>$max)$this->fail(422,'Enter a valid '.$key.'.');return $value; }
    private function ok(array $data,int $status=200): never { throw new JsonResponse($status,$data); }
    private function fail(int $status,string $message): never { throw new JsonResponse($status,['error'=>$message]); }
}

final class JsonResponse extends RuntimeException
{ public function __construct(public int $status,public array $payload){parent::__construct();} }
