<?php
declare(strict_types=1);

final class Database
{
    public static function connect(array $settings): PDO
    {
        if (($settings['name'] ?? '') !== 'somaspac_shulelite') throw new RuntimeException('Invalid database name.');
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', $settings['host'], $settings['name']);
        return new PDO($dsn, $settings['username'], $settings['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
}
