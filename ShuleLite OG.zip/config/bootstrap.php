<?php
declare(strict_types=1);

$configFile = dirname(__DIR__) . '/config/config.php';
if (!is_file($configFile)) { http_response_code(503); exit('Copy config/config.example.php to config/config.php and configure the database.'); }
$config = require $configFile;
if (($config['database']['name'] ?? '') !== 'somaspac_shulelite') { http_response_code(503); exit('ShuleLite only accepts the somaspac_shulelite database.'); }
date_default_timezone_set($config['app']['timezone'] ?? 'Africa/Dar_es_Salaam');
header_remove('X-Powered-By');
require_once dirname(__DIR__) . '/src/Database.php';
require_once dirname(__DIR__) . '/src/Security.php';
require_once dirname(__DIR__) . '/src/Language.php';
session_name($config['app']['session_name'] ?? 'SHULELITESESSID');
session_set_cookie_params(['httponly' => true, 'secure' => !empty($_SERVER['HTTPS']), 'samesite' => 'Lax', 'path' => '/']);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (isset($_SESSION['last_seen']) && time() - (int) $_SESSION['last_seen'] > 7200) { $_SESSION = []; session_destroy(); session_start(); }
$_SESSION['last_seen'] = time();
$pdo = Database::connect($config['database']);
