<?php
declare(strict_types=1);

return [
    'database' => [
        'host' => '127.0.0.1',
        'name' => 'somaspac_shulelite',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'name' => 'ShuleLite',
        'base_url' => 'http://shulelite.local',
        'session_name' => 'SHULELITESESSID',
        'timezone' => 'Africa/Dar_es_Salaam',
    ],
];
