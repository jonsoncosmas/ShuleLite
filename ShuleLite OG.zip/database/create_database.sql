CREATE DATABASE IF NOT EXISTS `somaspac_shulelite`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
