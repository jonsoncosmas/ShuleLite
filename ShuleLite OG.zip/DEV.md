# ShuleLite developer guide

**Date updated:** 2026-10-17  
**Current phase:** Phase 1 schools, users and login (partial; Phase 2 framework foundation added)  
**Local setup:** From the project root, copy config with `Copy-Item config/config.example.php config/config.php`, create MariaDB database `somaspac_shulelite` using utf8mb4, then run `php bin/migrate.php` and `php bin/create_system_admin.php joh`. Configure Apache so `public_html/` is the only document root. The CLI prints a one-time temporary password; do not save it in this file.

## Test accounts

| Username | Role | School | How created |
|---|---|---|---|
| None yet | — | — | Generate the first System Admin with `php bin/create_system_admin.php <username>` after migrations. |

## Phase summary

| Phase | Name | Built | Features | Tested by Joh |
|---|---|---|---|---|
| 0 | Foundation | Partial | Initial PHP scaffold, config guard, PDO, migration CLI, security helpers, English keys, base responsive shell, health route | 0 of 0 |
| 1 | Schools, users, login | Partial | User/school schema, CLI admin creation, login, password change, login throttling, Director/Sub System Admin management and grants, school management, audit list | 0 of 0 |
| 2 | Roles and permissions framework | Partial | Permission catalog, 21 role catalog entries, scoped grant checks, staff account management page and API | 0 of 0 |
| 3 | Academic structure | No | Not built yet | 0 of 0 |
| 4 | People records | No | Not built yet | 0 of 0 |
| 5 | Teaching and curriculum | No | Not built yet | 0 of 0 |
| 6 | Assessment and exams | No | Not built yet | 0 of 0 |
| 7 | Attendance and discipline | No | Not built yet | 0 of 0 |
| 8 | Communication | No | Not built yet | 0 of 0 |
| 9 | Parent and student portals | No | Not built yet | 0 of 0 |
| 10 | Finance | No | Not built yet | 0 of 0 |
| 11 | Subscriptions and revenue | No | Not built yet | 0 of 0 |
| 12 | HR | No | Not built yet | 0 of 0 |
| 13 | Procurement, stores, inventory | No | Not built yet | 0 of 0 |
| 14 | SomaBus | No | Not built yet | 0 of 0 |
| 15 | Holiday Learning Packages | No | Not built yet | 0 of 0 |
| 16 | AI proxy and features | No | Not built yet | 0 of 0 |
| 17 | Swahili, hardening, polish | No | Not built yet | 0 of 0 |

## Phase 0 — Foundation

- [ ] **P0-F01 Local application foundation** — Role: developer. Where: project root and `/health`. What it does: provides the DB-only health response and secure app bootstrap. How to test: 1) configure `config/config.php` 2) visit `/health`. Expected: JSON reports ShuleLite status. Agent smoke check: not run yet.

Migrations added: `001_foundation.sql`. New config keys: database host/name/username/password/charset; app name/base_url/session_name/timezone. Language files touched: `lang/en.php`. Known gaps / assumptions: the health route currently connects to the database before responding; no initial System Admin exists until the CLI command is run. Setup commands assume PowerShell and XAMPP MariaDB.

## Phase 1 — Schools, users, login

- [ ] **P1-F01 Sign in and sign out** — Role: all registered users. Where: `/login`, `/logout`. What it does: authenticates using username/password and ends the current session. How to test: 1) create a System Admin using the CLI 2) sign in with the printed temporary password 3) sign out. Expected: valid credentials open the workspace and sign out returns to login; repeated failures are throttled. Prohibited-action test: an unauthenticated user visits `/admin/audit` and is redirected to sign in. Agent smoke check: not run yet.
- [ ] **P1-F02 Change temporary password** — Role: signed-in user. Where: `/change-password`. What it does: requires temporary-password users to set a new password. How to test: 1) sign in with a generated admin password 2) set and confirm a 12-character password. Expected: next visit uses the new password. Prohibited-action test: a signed-out user posts to `/change-password` and receives 401. Agent smoke check: not run yet.
- [ ] **P1-F03 Audit activity view** — Role: System Admin or Sub Director (initial scaffold). Where: `/admin/audit`. What it does: lists recent audit actions without change payloads. How to test: 1) sign in as System Admin 2) open Audit log. Expected: recent actions appear or a clear empty row is shown. Prohibited-action test: a Director requests `/admin/audit` and receives 403. Agent smoke check: not run yet.
- [ ] **P1-F04 Create and view schools** — Role: Director; Sub Director with `schools.edit` / `schools.view`. Where: `/schools`. What it does: creates a school with a generated `SL-XXXXXX` code and lists schools in the caller's permitted scope. How to test: 1) sign in as a Director 2) open `/schools` 3) add a school. Expected: the new code and school details appear. Prohibited-action test: a Student calls `POST /api/schools` and receives 403. School A vs School B isolation test: create separate schools for Director A and Director B; each list contains only the caller's school. Agent smoke check: not run yet.
- [ ] **P1-F05 Register Directors and issue temporary passwords** — Role: System Admin or Sub Director with `director.register`. Where: `/admin/directors`. What it does: creates a Director account, shows a one-time temporary password, and forces a password change at first login. How to test: 1) sign in with an authorized account 2) register a unique username 3) note the temporary password 4) sign in as that Director. Expected: first login requires a new password. Prohibited-action test: an ordinary Director posts to `/api/directors` and receives 403. Agent smoke check: not run yet.
- [ ] **P1-F06 Director status and password reset** — Role: System Admin or Sub Director with the matching permission. Where: `/admin/directors` and `/api/directors/{id}/status`, `/api/directors/{id}/reset-password`. What it does: suspends/reactivates a Director or issues a one-time reset password that invalidates existing sessions. How to test: 1) select a Director 2) suspend or reset the password 3) try using an old session. Expected: suspended/old sessions are rejected and reset requires a new password. Prohibited-action test: Director cannot suspend another Director or reset their password. Agent smoke check: not run yet.

Migrations added: `001_foundation.sql`. New config keys: none. Language files touched: `lang/en.php`. Known gaps / assumptions: dedicated workflows for school status and permission-gated school updates are still limited; management screens require Apache rewrite support. The bootstrap and login/management flows have not been smoke-checked.

## Phase 2 — Roles and permissions framework (partial foundation)

- [ ] **P2-F01 Database permission catalog and scoped grant checks** — Role: System Admin manages platform grants; Sub System Admin exercises only active granted permissions. Where: migrations `002_role_permissions.sql` and `004_distinct_delegated_roles.sql`, `/admin/users` and `/api/*`. What it does: checks platform/school scoped grants on each request. How to test: grant an active permission, call its endpoint, revoke the grant and retry. Expected: access changes on the next request. Prohibited-action test: Sub System Admin cannot create another Sub System Admin or edit grants. School A vs School B isolation test: grant School A only and confirm School B remains inaccessible. Agent smoke check: not run yet.

Migrations added: `002_role_permissions.sql`. New config keys: none. Language files touched: `lang/en.php`. Known gaps / assumptions: catalog activation is limited to the six initial platform permissions. A full 20-role permission matrix, school-level account creation, scoped staff delegation and accessible grant-management UI remain to be built.

## Assumptions register

- All 20 roles and their per-feature permission scopes are not yet implemented; only the initial role strings exist.
- Local default DB username is `root` with a blank password, matching a common XAMPP setup; Joh should set the local config to his own environment.
- New passwords require at least 12 characters.
- School codes, role assignment UI and school context selection are not implemented.

## Known issues and deferred items

- Phases 2–17 remain unbuilt. Do not use this scaffold for school records.
- Login attempt throttling is recorded per username and IP over 15 minutes, but the current table-based counter is not atomic under concurrent requests.
- Audit event coverage is only a small initial slice. The audit table has no retention/export flow.
- Git operations could not run because Git rejects this workspace as an unsafe directory owned by a different Windows account. The directory was initialized locally, but repository commits, branches and pushes need the owner's Git safe-directory setup.
- Pushes could not be attempted after repository initialization because Git's safe-directory check blocked Git operations; no `origin` remote was present at initial inspection.
- Agent smoke check: ran / not run — not run; PHP, MariaDB and Apache checks were unavailable from the current tool session.

## Needs Joh

- Configure Git's safe-directory for this path under the intended Windows account, then initialize/preserve the requested branch and commit plan. Add `origin` only after confirming the repository URL and credentials.
- Confirm official Tanzanian requirements for student data about minors; no legal requirement is stated here as fact.
- Review all role scopes and business-rule assumptions before building the later role-gated workflows.

## Reading order

Read the phase summary first, then follow the local setup, then use each phase checklist in order. Only Joh should tick checklist boxes.

## Local browser checklist

Open `http://shulelite.local/dev.html` for a clickable phase-by-phase manual test checklist. Its checked items are stored only in the current browser's local storage and do not change this tracked guide. Open `database/create_database.sql` in phpMyAdmin's SQL tab to create the required utf8mb4 database; the local phpMyAdmin UI was not accessible from this session, so the SQL has not been executed here.

### Continued implementation notes (2026-10-17)

Additional partial Phase 1 endpoints and screens: `/schools` and `/admin/directors`; JSON endpoints are `/api/schools`, `/api/directors` and associated status/reset routes. Changes are saved asynchronously. Apply all numbered migrations through `004_distinct_delegated_roles.sql` before using the latest account and grant workflows.

CLI fallback: `php bin/create_director.php [username]` creates a Director, prints a one-time temporary password, forces password change at first login, and writes an audit entry. If username is omitted, a random `director-xxxxxx` username is generated. Requires local config and migrations through `001_foundation.sql`.

Account management page: sign in and open `/admin/users`. A System Admin can create Director and Sub Director accounts and edit active permission grants by platform or school scope. A Director or Sub Director with `staff.create` can create school accounts, including Admin/Account Manager, only in a school they own or have been granted. System Admin cannot create school staff. “Sub System Admin” is not a role; use the single **Sub Director** role.

Additional partial Phase 2 work: `003_school_roles.sql` seeds the role catalog and school-scoped user-role links. `POST /api/staff` creates a linked school staff user and one-time temporary password; `/admin/users` provides a user-facing account screen. School scoping is enforced for Director-owned schools and Sub System Admin grants; other role permissions and context handling remain incomplete.

The earlier Git setup blocker still applies. No branch, commit or push was made. Agent smoke checks remain not run.

## Role model correction from Joh (2026-10-17)

- **Sub System Admin** and **Sub Director** are separate roles. Sub System Admin is a delegated platform administrator; it receives only the permissions granted by a System Admin. Sub Director is a school-level School Manager.
- Migration `004_distinct_delegated_roles.sql` adds the Sub System Admin platform role, moves Sub Director to school scope, copies existing per-user delegated grants into `subsystemadmin_grants`, and reclassifies legacy Sub Director platform accounts as Sub System Admin.
- The System Admin account page is `/admin/users`. System Admin can create Directors and Sub System Admins and grant the latter available permissions. Director and Sub Director school account creation is limited by the server-side `staff.create` permission and school membership. Sub System Admin can create school staff only with an explicit school-scoped `staff.create` grant. System Admin cannot create school staff accounts.
- No implicit management permissions are assigned to Sub Director accounts. Their allowed school-manager actions require explicit server-side permissions. The exact School Manager permission set is still an assumption to review before enabling school operations.
- The older role checklist text elsewhere in this guide was written for the superseded single-role interpretation; use this correction and the `004` migration as the current role definition.
- School staff creation now requires both `staff.create` and `roles.assign` within the target school. Neither permission is silently granted to Sub Directors. The System Admin account UI can grant these to a Sub System Admin per school; the current grant UI does not yet assign per-user school-role permissions to a Sub Director.
- Automatic `roles.assign` grants for every Director were not added: automatic approval review rejected granting that permission broadly. A Director who has not explicitly received `roles.assign` will see the endpoint deny staff-account creation.
- Agent smoke check: not run yet. Migration `004` has not been run against MariaDB in this session.

## System Admin dashboard: Directors and School Managers

- The authenticated System Admin dashboard (`/`) now has direct links to Director accounts and `Sub Directors (School Managers)`.
- `/admin/school-managers` and `POST /api/school-managers` are System Admin-only. The form requires an active school and creates a Sub Director login linked to that school with a one-time temporary password and forced password change. The list shows each manager's school association.
- Manual check: sign in as System Admin, open the dashboard, select Sub Directors (School Managers), create a test account for an active school, then confirm it appears in the list. Confirm the response displays the temporary password once. Prohibited-action check: sign in as a Director and request `/admin/school-managers`; expect 403. Isolation check: confirm the created manager has only the selected school's membership.
- This account-provisioning action does not grant the School Manager additional school-operation permissions. Those remain subject to explicit permissions.
- Agent smoke check: not run yet; shell/browser unavailable.
