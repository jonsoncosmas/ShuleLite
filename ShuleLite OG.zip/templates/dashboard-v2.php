<?php
$title = __('nav.dashboard');
$isSystemAdmin = in_array($currentUser['role'] ?? '', ['System Admin', 'Sub System Admin'], true);
$isAdmin = ($currentUser['role'] ?? '') === 'Admin';
$isDirector = ($currentUser['role'] ?? '') === 'Director';
require __DIR__ . '/partials/header.php';
?>
<main class="dashboard-shell">
  <section class="welcome-panel">
    <p class="eyebrow"><?= e(__('dashboard.eyebrow')) ?></p>
    <h1><?= e(__('dashboard.welcome', ['name' => $currentUser['full_name'] ?? ''])) ?></h1>
    <p><?= e(__('dashboard.intro')) ?></p>
  </section>
  <?php if ($isSystemAdmin): ?>
  <section class="admin-actions">
    <h2><?= e(__('dashboard.platform_title')) ?></h2>
    <p><?= e(__('dashboard.platform_description')) ?></p>
    <a class="action-card" href="/admin/directors">
      <span class="action-card__icon" aria-hidden="true">D</span>
      <span><strong><?= e(__('dashboard.directors_title')) ?></strong><small><?= e(__('dashboard.directors_description')) ?></small></span>
      <span class="action-card__arrow" aria-hidden="true">→</span>
    </a>
  </section>
  <?php elseif ($isAdmin): ?>
  <section class="admin-actions">
    <h2><?= e(__('dashboard.admin_title')) ?></h2>
    <p><?= e(__('dashboard.admin_description')) ?></p>
    <div class="action-grid">
      <a class="action-card" href="/schools"><span class="action-card__icon" aria-hidden="true">S</span><span><strong><?= e(__('dashboard.schools_title')) ?></strong><small><?= e(__('dashboard.schools_description')) ?></small></span><span class="action-card__arrow" aria-hidden="true">→</span></a>
      <a class="action-card" href="/admin/directors"><span class="action-card__icon" aria-hidden="true">D</span><span><strong><?= e(__('dashboard.directors_title')) ?></strong><small><?= e(__('dashboard.directors_description')) ?></small></span><span class="action-card__arrow" aria-hidden="true">→</span></a>
    </div>
  </section>
  <?php elseif ($isDirector): ?>
  <section class="admin-actions">
    <h2><?= e(__('dashboard.school_title')) ?></h2>
    <p><?= e(__('dashboard.school_description')) ?></p>
    <div class="action-grid">
      <a class="action-card" href="/schools"><span class="action-card__icon" aria-hidden="true">S</span><span><strong><?= e(__('dashboard.schools_title')) ?></strong><small><?= e(__('dashboard.schools_description')) ?></small></span><span class="action-card__arrow" aria-hidden="true">→</span></a>
      <a class="action-card" href="/admin/school-managers"><span class="action-card__icon" aria-hidden="true">M</span><span><strong><?= e(__('dashboard.managers_title')) ?></strong><small><?= e(__('dashboard.managers_description')) ?></small></span><span class="action-card__arrow" aria-hidden="true">→</span></a>
    </div>
  </section>
  <?php else: ?>
  <section class="welcome-panel"><p><?= e(__('dashboard.role_landing')) ?></p></section>
  <?php endif; ?>
</main>
<?php require __DIR__ . '/partials/footer.php'; ?>
